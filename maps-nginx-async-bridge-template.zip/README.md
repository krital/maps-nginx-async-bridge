# MAPS Messaging Async Bridge Template

This template bootstraps a multi-protocol gateway powered by **MAPS Messaging** and **NGINX + Lua**, offering REST-to-WebSocket bridging with correlation-aware asynchronous replies.

## Features
- RESTful endpoint translation to WebSocket/other protocols
- Correlation-based message routing via MAPS Messaging
- TLS termination with optional secrets
- Deployable via **Docker Compose**, **systemd**, **Kubernetes**, or **Helm**
- Optional metrics/logging with Prometheus, Loki, and Grafana

## Getting Started

### Local Dev with Docker Compose
```bash
docker-compose up --build
```

### Production with systemd
```bash
sudo systemctl enable maps-nginx
sudo systemctl start maps-nginx
```

### Kubernetes with Helm
```bash
helm install maps-nginx ./helm -f helm/values.yaml
```

## Directory Structure
(See full deployment guide for layout)

## CI/CD
GitHub Actions builds and tests the Compose stack and TLS proxy endpoint.

## License
MIT License © 2025 MAPS Messaging BV
